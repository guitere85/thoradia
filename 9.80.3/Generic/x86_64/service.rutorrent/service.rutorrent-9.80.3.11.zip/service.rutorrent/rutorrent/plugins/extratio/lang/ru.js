﻿/*
 * PLUGIN EXTRATIO
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.ratioRulesManager	= "Менеджер правил";
 theUILang.mnu_ratiorule	= "Правила ratio";
 theUILang.ratAddRule		= "Добавить";
 theUILang.ratDelRule		= "Удалить";
 theUILang.ratUpRule		= "Вверх";
 theUILang.ratDownRule		= "Вниз";
 theUILang.ratioIfLegend	= "Если";
 theUILang.ratLabelContain	= "Метка закачки содержит";
 theUILang.ratTrackerContain	= "Один из URL трекеров закачки содержит";
 theUILang.ratTrackerPublic	= "Все трекеры закачки публичные";
 theUILang.ratTrackerPrivate	= "Один из трекеров закачки частный";
 theUILang.ratioThenLegend	= "То";
 theUILang.setRatioTo		= "Установить ratio";
 theUILang.setChannelTo		= "Установить канал";
 theUILang.ratioNewRule		= "Новое правило";

thePlugins.get("extratio").langLoaded();