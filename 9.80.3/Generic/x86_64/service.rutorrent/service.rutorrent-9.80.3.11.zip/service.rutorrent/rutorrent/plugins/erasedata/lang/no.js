﻿/*
 * PLUGIN ERASEDATA
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.Rem_torrents_content_prompt		= "Vil du virkelig fjerne den valgte torrenten(e)? ADVARSEL: Dette vil slette torrentens innhold.";
 theUILang.Delete_data_with_path		= "Slett Mappe";
 theUILang.Rem_torrents_with_path_prompt	= "Vil du virkelig slette den valgte torrenten(e)? ADVARSEL: Dette vil slette alle filene i torrentens nåværende mappe.";

thePlugins.get("erasedata").langLoaded();