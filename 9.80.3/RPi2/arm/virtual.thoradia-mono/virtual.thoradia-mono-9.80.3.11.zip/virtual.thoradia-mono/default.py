import xbmcgui

dialog = xbmcgui.Dialog()
dialog.ok('', 'This is a console-only addon')
