﻿/*
 * PLUGIN DATADIR
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.DataDir		= "Сохранить в";
 theUILang.DataDirMove		= "Перенести файлы данных";
 theUILang.datadirDlgCaption	= "Настройка каталога данных";
 theUILang.datadirDirNotFound	= "Плагин DataDir: Недопустимый каталог";
 theUILang.datadirSetDirFail	= "Плагин DataDir: Операция не выполнена";

thePlugins.get("datadir").langLoaded();