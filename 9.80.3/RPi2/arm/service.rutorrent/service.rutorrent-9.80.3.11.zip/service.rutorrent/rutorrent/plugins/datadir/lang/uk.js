﻿/*
 * PLUGIN DATADIR
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.DataDir		= "Зберегти до";
 theUILang.DataDirMove		= "Перемістити файли даних";
 theUILang.datadirDlgCaption	= "Настройка каталогу даних";
 theUILang.datadirDirNotFound	= "Плагін DataDir: неприпустимий каталог";
 theUILang.datadirSetDirFail	= "Плагін DataDir: операцію не виконано";

thePlugins.get("datadir").langLoaded();