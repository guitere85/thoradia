﻿/* PLUGIN _CLOUDFLARE
 *
 * Polish language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCloudscraper		= "Wtyczka _cloudflare: Nie można załadować w Pythonie modułu cloudscraper";

thePlugins.get("_cloudflare").langLoaded();
