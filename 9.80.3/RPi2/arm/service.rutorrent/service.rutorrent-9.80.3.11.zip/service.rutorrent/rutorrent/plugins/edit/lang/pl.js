﻿/*
 * PLUGIN EDIT
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.EditTrackers			= "Edytuj torrent...";
 theUILang.EditTorrentProperties	= "Właściwości torrenta";
 theUILang.errorAddTorrent		= "Błąd podczas dodawania pliku torrent";
 theUILang.errorWriteTorrent		= "Błąd podczas zapisywania pliku torrent";
 theUILang.errorReadTorrent		= "Błąd podczas odczytu pliku torrent";
 theUILang.cantFindTorrent		= "Źródło pliku torrent dla tego pobrania nie zostało znalezione."

thePlugins.get("edit").langLoaded();