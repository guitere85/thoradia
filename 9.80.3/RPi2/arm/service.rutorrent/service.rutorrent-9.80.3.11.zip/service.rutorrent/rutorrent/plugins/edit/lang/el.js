﻿/*
 * PLUGIN EDIT
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.EditTrackers			= "Επεξεργασία Torrent...";
 theUILang.EditTorrentProperties	= "Ιδιότητες του Torrent";
 theUILang.errorAddTorrent		= "Σφάλμα κατά την προσθήκη του αρχείου torrent";
 theUILang.errorWriteTorrent		= "Σφάλμα κατά την εγγραφή στο αρχείο torrent";
 theUILang.errorReadTorrent		= "Σφάλμα κατά την ανάγνωση από το αρχείο torrent";
 theUILang.cantFindTorrent		= "Το πηγαίο αρχείο torrent για αυτή τη λήψη δεν βρέθηκε."

thePlugins.get("edit").langLoaded();